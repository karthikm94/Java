package com.mobile.application.model;

import java.util.ArrayList;
import java.util.List;

public class Image {
	public List<String> imageList(){
		List <String>img = new ArrayList<String>();
		img.add("BOAT");
		return img;
		
	}

}
