package com.mobile.application.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobile.application.model.Item;
import com.mobile.application.repository.ItemRepository;


@Service
@Transactional
public class ItemService {
	
	@Autowired
	private ItemRepository itemRepo;

	public ItemService(ItemRepository itemRepo) {
		
		this.itemRepo = itemRepo;
	} 
  public void fetchAitem (Item i) {
	  
	  int id=i.getCategoryid();
	  itemRepo.findById(id);
  }
public List<Item> listAll() {
	// TODO Auto-generated method stub
	  
	return (List<Item>) itemRepo.findAll();
}



}
