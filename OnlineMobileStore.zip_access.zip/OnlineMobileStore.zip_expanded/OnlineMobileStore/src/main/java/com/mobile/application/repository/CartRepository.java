package com.mobile.application.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobile.application.model.Cart;
@Repository
public interface CartRepository extends CrudRepository<Cart, String> {

}
