package com.mobile.application.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.ModelAndViewDefiningException;

import com.mobile.application.model.Cart;
import com.mobile.application.model.Item;
import com.mobile.application.model.Orders;
import com.mobile.application.model.User;
import com.mobile.application.repository.CartRepository;
import com.mobile.application.repository.ItemRepository;
import com.mobile.application.repository.OrdersRepository;
import com.mobile.application.repository.UserRepository;
import com.mobile.application.service.CartService;
import com.mobile.application.service.ItemService;
import com.mobile.application.service.OrdersService;
import com.mobile.application.service.UserService;
//import com.mobile.application.service.UserService;

@Controller
//@RequestMapping(path="/home")
	public class ApplicationController {
	 
	@Autowired
	private UserRepository userRepository; 
	private UserService userService;
	
	@Autowired
	private CartRepository cartRepository;
	private CartService cartService;
	
	@Autowired
	private OrdersRepository orderRepository;
	private OrdersService orderService;
	
	
	    @RequestMapping("/home")
	    public String home() {
	   
	        return "home";
	    }
	    
	    
	    @RequestMapping("/login")
	    public String login() {
	   
	        return "login";
	    }
	    
	    @RequestMapping("/register")
	    public String register() {
	   
	        return "register";
	    }
	    
	    @RequestMapping("/welcome")
	    public String welcome() {
	   
	        return "welcome";
	    }
	    @RequestMapping("/access")
	    public String access() {
	   
	        return "access";
	    }
	    @RequestMapping("/addaccess")
		public String addaccess()
		{
			return "/addaccess";
		}

	    
		//Login	  ,BindingResult bindingResult
	    @PostMapping(path="/validateuser")
		public ModelAndView ValidateUser(@ModelAttribute User user) {
	    	
	    	List<User> l=userService.FetchUser();
	    	String log="login";
	    	for(var l1:l)
	    	{
	    		if(l1.getEmail()==user.getEmail())
	    		{
	    			User u=userService.ValidateUser(user);
	    			if((u.getEmail()==user.getEmail())&& u.getPassword()==user.getPassword()&& u.getRoleid()==1 )
	    			{
	    				log="register";
	    			}
	    			else if((u.getEmail()==user.getEmail())&& u.getPassword()==user.getPassword()&& u.getRoleid()==2)
	    			{
	    				log="admin";
	    			}
	    			else
	    				log="login";
	    		}
	    	}
		    ModelAndView m=new  ModelAndView(log)	;
		    m.addObject("message ", "Invallid");
			return m;
	    }
	   	
		/*
		  public Cart give() { Cart c= new Cart("nanda@",1001,2); return c; }
		 */
	    
	    
	    @RequestMapping(path="/cart")
	    
	    public String cart()
	    {
	    	return "cart";
	    }
	    
	    //cart
	    @PostMapping(path="/save-cart")
	    
		public ModelAndView saveCart(Cart cart) {
	    	  	
	    	int t=(int) (cart.getPrice() * cart.getQuantity());
			cart.setTotal(t);	
	    Cart c=	cartRepository.save(cart);
	    ModelAndView m=new  ModelAndView("orders")	;
	    m.addObject("l", c);
			return m;
	    }
	    
	    //orders
	    @PostMapping(path="/save-order")
	    public ModelAndView order(Orders order) {
	    	
	    Orders o=	orderRepository.save(order);
	    ModelAndView m=new  ModelAndView("orderSuccess");
	    m.addObject("cart", o);
			return m;
	    }
	    
	    
	    
	    
	//Registration	
			@PostMapping(path="/save-user")
			public ModelAndView registerUser(User user) {
			User u=	userRepository.save(user);
		    ModelAndView m=new  ModelAndView("successpage")	;
		    m.addObject("l", u);
				return m;
				
			
		}
		
	    //access
			@Autowired
			private ItemService itemService;
		//	@PostMapping("/view-power")
		    public ModelAndView power() {
				Item i = new Item();
		        int p= 17;
		        i.setProductid(p);
		        List<Item> listitem = itemService.listAll();
		        ModelAndView m = new ModelAndView ("accessview");
		        m.addObject("listitem",listitem );
		       // System.out.println("Get /");
		        
		        
		        return m;
		    }

	       
	    
	}