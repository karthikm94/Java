package com.mobile.application.repository;

import org.springframework.data.repository.CrudRepository;

import com.mobile.application.model.Orders;

public interface OrdersRepository extends CrudRepository<Orders, String> {

}
