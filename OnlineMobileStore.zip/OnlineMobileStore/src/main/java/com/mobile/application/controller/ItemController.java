package com.mobile.application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mobile.application.model.Item;
import com.mobile.application.repository.ItemRepository;
import com.mobile.application.service.ItemService;

@Controller
//@RequestMapping("/accessories")

public class ItemController {
	
	@Autowired
	private ItemRepository itemRepository ;
	private ItemService itemService;
	
	
	
	@PostMapping("/saveaccess")
	public String saveaccess(Item i ) {
		
		itemRepository.save(i);
		return "accessories";
	}
	
	//@RequestMapping("/accessories")
	@PostMapping("/view-power")
	public ModelAndView power()
	{
		
		List<Item> item = (List <Item>) itemRepository.findAll();

		List<Item> l=new ArrayList<>();
		int p = 17; 
		//String a ="AMBRANE";
		for (var i: item)
		{
			if (i.getProductid()==(p))
			{
				l.add(i);
			}
		}
		ModelAndView m= new ModelAndView("accessview");
		m.addObject("list", l);
		return m;
	}
	
	

	@PostMapping("/view-headset")
    public ModelAndView headset() {
		
		List<Item> item = (List <Item>) itemRepository.findAll();

		List<Item> l=new ArrayList<>();
		int p = 18; 
		
		for (var i: item)
		{
			if (i.getProductid()==(p))
			{
				l.add(i);
			}
		}
		ModelAndView m= new ModelAndView("accessview");
		m.addObject("list", l);
		return m;
    }

		@PostMapping("/view-charger")
		public ModelAndView charger() {
			List<Item> item = (List <Item>) itemRepository.findAll();

			List<Item> l=new ArrayList<>();
			int p = 19; 
			
			for (var i: item)
			{
				if (i.getProductid()==(p))
				{
					l.add(i);
				}
			}
			ModelAndView m= new ModelAndView("accessview");
			m.addObject("list", l);
			return m;
		}

			@PostMapping("/view-cover")
			public ModelAndView cover() {
				List<Item> item = (List <Item>) itemRepository.findAll();

				List<Item> l=new ArrayList<>();
				int p = 20; 
				
				for (var i: item)
				{
					if (i.getProductid()==(p))
					{
						l.add(i);
					}
				}
				ModelAndView m= new ModelAndView("accessview");
				m.addObject("list", l);
				return m;
			}
			
			@PostMapping("/view-screen")
			public ModelAndView screen() {
				List<Item> item = (List <Item>) itemRepository.findAll();

				List<Item> l=new ArrayList<>();
				int p = 21; 
				
				for (var i: item)
				{
					if (i.getProductid()==(p))
					{
						l.add(i);
					}
				}
				ModelAndView m= new ModelAndView("accessview");
				m.addObject("list", l);
				return m;
			}
		
			@PostMapping("/view-usb")
			public ModelAndView usb() {
				List<Item> item = (List <Item>) itemRepository.findAll();

				List<Item> l=new ArrayList<>();
				int p = 22; 
				
				for (var i: item)
				{
					if (i.getProductid()==(p))
					{
						l.add(i);
					}
				}
				ModelAndView m= new ModelAndView("accessview");
				m.addObject("list", l);
				return m;
			}


}
