package com.mobile.application.model;


import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="item")

public class Item {
	
	@Id
	
	
	private int model;
	
	private String itemname;
	
	private String color;
	
	private int price;
	
	private String features;
	

	
	private int productid;
	
	private int categoryid;
	
	private int quantity_available;

	public int getModel() {
		return model;
	}

	public void setModel(int model) {
		this.model = model;
	}

	public String getItemname() {
		return itemname;
	}

	public void setItemname(String itemname) {
		this.itemname = itemname;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public String getFeatures() {
		return features;
	}

	public void setFeatures(String features) {
		this.features = features;
	}


	

	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public int getCategoryid() {
		return categoryid;
	}

	public void setCategoryid(int categoryid) {
		this.categoryid = categoryid;
	}

	public int getQuantity_available() {
		return quantity_available;
	}

	public void setQuantity_available(int quantity_available) {
		this.quantity_available = quantity_available;
	}


	
	public Item(int model, String itemname, String color, int price, String features, int productid,
			int categoryid, int quantity_available) {
		super();
		this.model = model;
		this.itemname = itemname;
		this.color = color;
		this.price = price;
		this.features = features;
		
		this.productid = productid;
		this.categoryid = categoryid;
		this.quantity_available = quantity_available;
	}

	public Item() {
	}

	@Override
	public String toString() {
		return "Item [model=" + model + ", itemname=" + itemname + ", color=" + color + ", price=" + price
				+ ", features=" + features + ", productid=" + productid + ", categoryid=" + categoryid
				+ ", quantity_available=" + quantity_available + "]";
	}

	
	
	
}
